#ifndef __wasilibc_sys_uio_h
#define __wasilibc_sys_uio_h

#include <__struct_iovec.h>

#endif
