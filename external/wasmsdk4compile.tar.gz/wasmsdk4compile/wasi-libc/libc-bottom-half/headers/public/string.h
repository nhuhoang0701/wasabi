#ifndef __wasilibc_string_h
#define __wasilibc_string_h

/*
 * Include the real implementation, which is factored into a separate file so
 * that it can be reused by other libc string implementations.
 */
#include <__header_string.h>

#endif
