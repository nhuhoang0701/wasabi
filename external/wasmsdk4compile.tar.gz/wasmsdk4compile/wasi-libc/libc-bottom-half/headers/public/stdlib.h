#ifndef __wasilibc_stdlib_h
#define __wasilibc_stdlib_h

/*
 * Include the real implementation, which is factored into a separate file so
 * that it can be reused by other libc stdlib implementations.
 */
#include <__functions_malloc.h>

#endif
