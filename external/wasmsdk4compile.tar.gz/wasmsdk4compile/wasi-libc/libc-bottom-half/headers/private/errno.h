#include_next <errno.h>
#define EOPNOTSUPP ENOTSUP
