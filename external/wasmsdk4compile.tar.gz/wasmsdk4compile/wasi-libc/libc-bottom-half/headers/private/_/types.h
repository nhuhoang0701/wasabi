#include <_/cdefs.h>
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdarg.h>
#include <sys/types.h>

typedef uint64_t __uint64_t;
#define _UINT64_C UINT64_C
